import com.sun.j3d.loaders.Scene;
import com.sun.j3d.loaders.objectfile.ObjectFile;
import com.sun.j3d.utils.image.TextureLoader;
import com.sun.j3d.utils.universe.SimpleUniverse;
import com.sun.j3d.utils.universe.ViewingPlatform;

import javax.media.j3d.*;
import javax.swing.*;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;
import java.awt.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

public class Penguin extends JFrame {
    static SimpleUniverse universe;
    static Scene scene;
    static Map<String, Shape3D> nameMap;
    static BranchGroup root;
    static Canvas3D canvas;

    static TransformGroup penguin;
    static Transform3D transform3D;

    public Penguin() throws IOException {
        configureWindow();
        configureCanvas();
        configureUniverse();

        root= new BranchGroup();
        addImageBackground();

        addDirectionalLightToUniverse();
        addAmbientLightToUniverse();

        ChangeViewAngle();

        penguin = getPenguinGroup();
        root.addChild(penguin);

        addAppearance();
        root.compile();
        universe.addBranchGraph(root);
    }

    private void configureWindow()  {
        setTitle("Пингвин лаб5 вар 13");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void configureCanvas(){
        canvas=new Canvas3D(SimpleUniverse.getPreferredConfiguration());
        canvas.setDoubleBufferEnable(true);
        getContentPane().add(canvas, BorderLayout.CENTER);
    }

    private void configureUniverse(){
        universe= new SimpleUniverse(canvas);
        universe.getViewingPlatform().setNominalViewingTransform();
    }


    private void addDirectionalLightToUniverse() {
        BoundingSphere bounds = new BoundingSphere (new Point3d (0.0, 0.0, 0.0), 2000000.0);
        DirectionalLight light = new DirectionalLight(new Color3f(1, 1, 1), new Vector3f(1, -1, -1));
        light.setInfluencingBounds(bounds);

        root.addChild(light);
    }
    private void addAmbientLightToUniverse() {
        AmbientLight light = new AmbientLight(new Color3f(1, 1, 1));
        light.setInfluencingBounds(new BoundingSphere());
        root.addChild(light);
    }

    private void printModelElementsList(Map<String,Shape3D> nameMap){
        for (String name : nameMap.keySet()) {
            System.out.printf("Name: %s\n", name);}
    }
    private TransformGroup getPenguinGroup() throws IOException {
        scene = getSceneFromFile("source_folder//penguin.obj");
        nameMap=scene.getNamedObjects();
        //Print elements of your model:
        printModelElementsList(nameMap);
        penguin = new TransformGroup();
        penguin.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        for(var entity: nameMap.entrySet()){
            scene.getSceneGroup().removeChild(nameMap.get(entity.getKey()));
            penguin.addChild(nameMap.get(entity.getKey()));
        }

        transform3D = new Transform3D();
        transform3D.setScale(new Vector3d(0.4, 0.4, 0.4));
        Transform3D transform3D2 = new Transform3D();
        
        penguin.removeAllChildren();
        TransformGroup tg = new TransformGroup();
        tg.setTransform(transform3D2);
        penguin.setTransform(transform3D);
        penguin.addChild(tg);
        for(var entity: nameMap.entrySet()){
            tg.addChild(nameMap.get(entity.getKey()));
        }
        return penguin;
    }


    Texture getTexture(String path) {
        TextureLoader textureLoader = new TextureLoader(path,"LUMINANCE",canvas);
        Texture texture = textureLoader.getTexture();
        return texture;
    }

    private Appearance getForPenguin(){
        Appearance appearance = new Appearance();
        appearance.setTexture(getTexture("source_folder//penguin_color.jpg"));
        TextureAttributes texAttr = new TextureAttributes();
        texAttr.setTextureMode(TextureAttributes.COMBINE);
        appearance.setTextureAttributes(texAttr);
        return appearance;
    }


    private void addAppearance(){

        Shape3D penguin = nameMap.get("pinguin");
        penguin.setAppearance(getForPenguin());

    }


    private void addImageBackground(){
        TextureLoader t = new TextureLoader("source_folder//background.jpg", canvas);
        Background background = new Background(t.getImage());
        background.setImageScaleMode(Background.SCALE_FIT_ALL);

        BoundingSphere bounds = new BoundingSphere(new Point3d(0.0, 0.0, 0.0),100.0);
        background.setApplicationBounds(bounds);
        root.addChild(background);

    }

    private void ChangeViewAngle(){
        ViewingPlatform vp = universe.getViewingPlatform();
        TransformGroup vpGroup = vp.getMultiTransformGroup().getTransformGroup(0);
        Transform3D vpTranslation = new Transform3D();
        Vector3f translationVector = new Vector3f(0F, 0F, 6F);
        vpTranslation.setTranslation(translationVector);
        vpGroup.setTransform(vpTranslation);
    }

    private void addOtherLight(){
        Color3f directionalLightColor = new Color3f(Color.BLACK);
        Color3f ambientLightColor = new Color3f(Color.WHITE);
        Vector3f lightDirection = new Vector3f(-1F, -1F, -1F);

        AmbientLight ambientLight = new AmbientLight(ambientLightColor);
        DirectionalLight directionalLight = new DirectionalLight(directionalLightColor, lightDirection);

        Bounds influenceRegion = new BoundingSphere();

        ambientLight.setInfluencingBounds(influenceRegion);
        directionalLight.setInfluencingBounds(influenceRegion);
        root.addChild(ambientLight);
        root.addChild(directionalLight);
    }

    public static Scene getSceneFromFile(String location) throws IOException {
        ObjectFile file = new ObjectFile(ObjectFile.RESIZE);
        return file.load(new FileReader(location));
    }


    public static void main(String[]args){
        try {
            Penguin window = new Penguin();
            AnimationPenguin movement = new AnimationPenguin(penguin, transform3D, window);
            window.setVisible(true);
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}